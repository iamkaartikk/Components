﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;



namespace RestaurantAPI.Models
{
    public class Cuisine
    {
        [Key]
        public long RestaurantId { get; set; }
        public string CuisineName { get; set; }
        public long Occupancy { get; set; }
    }



}