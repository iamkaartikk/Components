﻿
using Microsoft.EntityFrameworkCore;

namespace RestaurantAPI.Models
{
    public class RestaurantBookingContext : DbContext
    {
        public DbSet<Restaurant> Restaurants { get; set; }
        public DbSet<Customer> customers { get; set; }

        public DbSet<Cuisine> cuisines { get; set; }
        public DbSet<RestaurantDetail> RestaurantDetails { get; set; }
        public DbSet<Reservation> Reservations { get; set; }










        public RestaurantBookingContext(DbContextOptions<RestaurantBookingContext> options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Restaurant>().ToTable("Restaurant");
            modelBuilder.Entity<Customer>().ToTable("Customer");
            modelBuilder.Entity<Cuisine>().ToTable("Cuisine");
            modelBuilder.Entity<RestaurantDetail>().ToTable("RestaurantDetail");
            modelBuilder.Entity<Reservation>().ToTable("Reservation");







        }
    }
}