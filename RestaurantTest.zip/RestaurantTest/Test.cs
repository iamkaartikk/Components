using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using RestaurantAPI.Controllers;
using RestaurantAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace RestaurantApi.Controllers
{
    public class RestaurantsController : Controller
    {
        public ActionResult Index()
        {
            // Add action logic here
            throw new NotImplementedException();
        }



        public ActionResult Details(int Id)
        {



            return View("Details");
        }
    }




    [TestFixture]
    public class RestaurantsControllerTest
    {
        [Test]
        public void TestDetailsView()
        {
            var controller = new RestaurantsController();
            var result = controller.Details(2) as ViewResult;
            Assert.AreEqual("Details", result.ViewName);



        }



        [TestFixture]
        public class RestaurantsController : Controller
        {
            [Test]
            public ActionResult Index()
            {
                // Add action logic here
                throw new NotImplementedException();
            }



            public ActionResult Details(int Id)
            {
                var restaurant = new Restaurant();
                
                return View("Details", restaurant);
            }
        }
    }
}