import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { variable } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-room',
  templateUrl: './room.component.html',
  styleUrls: ['./room.component.css']
})
export class RoomComponent {
  rooms=[
    {Num:'234',Room_type:'Premium',Room_view:'Pool',price:'4000',Occupancy:'4'},
    {Num:'345',Room_type:'Premium',Room_view:'Garden',price:'4500',Occupancy:'2'},
    {Num:'426',Room_type:'Executive',Room_view:'Pool',price:'4300',Occupancy:'5'},
    {Num:'303',Room_type:'Executive',Room_view:'Garden',price:'4800',Occupancy:'4'},
    {Num:'564',Room_type:'Executive',Room_view:'Mountain',price:'5200',Occupancy:'6'},
    {Num:'208',Room_type:'Suite',Room_view:'Pool',price:'5000',Occupancy:'3'},
    {Num:'567',Room_type:'Suite',Room_view:'Mountain',price:'5800',Occupancy:'2'},
    {Num:'130',Room_type:'Suite',Room_view:'Lake',price:'6500',Occupancy:'2'},
    {Num:'207',Room_type:'Suite',Room_view:'Pool',price:'5000',Occupancy:'3'},
    {Num:'408',Room_type:'Executive',Room_view:'Garden',price:'4800',Occupancy:'4'}

  ]
  hotel_id: string;
  constructor(private actRoute: ActivatedRoute) {
    this.hotel_id = this.actRoute.snapshot.params['id'];
  }
  ngOnInit(): void {
  }

}
